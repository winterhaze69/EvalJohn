<?php
require_once("./products.php");
$product_valide1 = "Camera";
$product_valide2 = "HardDrive";
$product_valide3 = "Watch";


if ($product_valide1 == $_POST['productName']) {
  session_start ();
  $_SESSION['productName'] = $_POST['productName'];
  foreach ($productArray as $product) {
    echo "$product[name]";
    echo "<img src=$product[image] alt='ok'>";
    echo "$product[price]";
    echo '<a href="./shop.php">Add</a>';
    echo '<a href="./reset.php">reset</a>';
    return true;
}
}elseif ($product_valide2 == $_POST['productName']) {
  session_start ();
  $_SESSION['productName2'] = $_POST['productName'];
     $decoupe = array_slice($productArray,1);
     foreach ($decoupe as $product2) {
       echo "$product2[name]";
       echo "<img src=$product2[image] alt='ok'>";
       echo "$product2[price]";
       echo '<a href="./shop.php">Add</a>';
       echo '<a href="./reset.php">reset</a>';
       return true;
}
}elseif ($product_valide3 == $_POST['productName']) {
  session_start ();
  $_SESSION['productName3'] = $_POST['productName'];
  $decoupe = array_slice($productArray,2);
  foreach ($decoupe as $product3) {
    echo "$product3[name]";
    echo "<img src=$product3[image] alt='ok'>";
    echo "$product3[price]";
    echo '<a href="./shop.php">Add</a>';
    echo '<a href="./reset.php">reset</a>';;
    return true;
}
}else {
  echo "nop";
  echo '<a href="./shop.php">Add</a>';
  echo '<a href="./reset.php">reset</a>';
}
