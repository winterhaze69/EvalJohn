<?php

$usersArray = array(
       "momo" => array(
           'id' => '1',
           'name' => 'maurice',
           'password' => '0000',
       ),
   );

  function getAllUsers($usersArray)
   {
     foreach ($usersArray as $user) {
       echo "$user[name]";
       echo "$user[password]";

     }

   }
