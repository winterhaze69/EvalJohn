<?php

 $productArray = array(
        "cam" => array(
            'id' => '1',
            'name' => 'Camera',
            'image' => 'product-images/camera.jpg',
            'price' => '1500.00E'
        ),
        "USB" => array(
            'id' => '2',
            'name' => 'HardDrive',
            'image' => 'product-images/external-hard-drive.jpg',
            'price' => '800.00E'
        ),
        "watch" => array(
            'id' => '3',
            'name' => 'Watch',
            'image' => 'product-images/watch.jpg',
            'price' => '300.00E'
        )
    );

   function getAllProducts($productArray)
    {
      foreach ($productArray as $product) {
        echo "$product[name]";
        echo "<img src=$product[image] alt='ok'>";
        echo "$product[price]";
      echo " <form method='post' action='/cart.php'>";
      echo "type the name of the product here before adding.
      <input type='text' name='productName' value='' required>
    <button type='submit'>Add</button>
</form>";
      }

    }
