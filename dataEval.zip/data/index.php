<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style1.css">
    <title>CV</title>
  </head>
  <body>

    <div class="title">
      <h1>ma</h1>
      <h1>boutique</h1>
      <h1>en ligne</h1>
    </div>
     <div>
       <?php
  require_once("./users.php");
  echo "users = ";
  getAllUsers($usersArray);
        ?>
     </div>
    <div class="connection">

      <form action="auth.php" method="post">
  Votre login : <input type="text" name="login">
  <br />
  Votre mot de passé : <input type="password" name="pwd"><br />
  <input type="submit" value="Connexion">
  </form>
    </div>
  </body>
</html>
