<?php
session_start();
if (isset($_SESSION['login']) && isset($_SESSION['pwd'])) {

echo '<!DOCTYPE html>';
echo '<html lang="en"><head>';
echo '<title>shopping Cart</title>';
echo '<link href="style.css" type="text/css" rel="stylesheet" />';
echo '</head>';
echo '<body>';
echo '<h1>myShop</h1>';
require_once("./products.php");

echo '<div class="clear-float"></div>';
echo '<div id="shopping-cart">';
//echo '<div class="txt-heading">Shopping Cart <a class="cart-action"><img src="images/icon-empty.png" /> Empty Cart</a></div>';

echo '<div id="cart-item">';

getAllProducts($productArray);

echo '</div>';
echo '</div>';
echo '<a href="./logout.php">Déconnection</a>';

echo '</body>';
echo '</html>';

}else {
	echo 'nop';
}
